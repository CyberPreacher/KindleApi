
from fastapi import FastAPI, HTTPException
from reader import KindleCloudReaderAPI
import os

app = FastAPI()

EMAIL = os.getenv("EMAIL")
PASSWORD = os.getenv("PASSWORD")

if not EMAIL or not PASSWORD:
    raise Exception("Bitte setze die Umgebungsvariablen EMAIL und PASSWORD!")

api = KindleCloudReaderAPI(EMAIL, PASSWORD)

@app.get("/library")
def get_library():
    return [book.__dict__ for book in api.get_library_metadata()]

@app.get("/progress/{asin}")
def get_progress(asin: str):
    book_progress = api.get_book_progress(asin)
    if not book_progress:
        raise HTTPException(status_code=404, detail="Kein Fortschritt für dieses Buch")
    _, current_page, last_page = book_progress.page_nums
    return {
        "current_page": current_page,
        "last_page": last_page
    }
