
# Kindle API (FastAPI Version)

**Starte lokal:**

```sh
pip install -r requirements.txt
EMAIL=deine@email.de PASSWORD=deinpasswort uvicorn main:app --reload
```

**Für Render.com oder Railway:**
- Als Web Service deployen
- `EMAIL` und `PASSWORD` als Umgebungsvariablen anlegen
- Startbefehl: `uvicorn main:app --host 0.0.0.0 --port 10000`

**API-Endpunkte:**

- `GET /library` – gibt alle Bücher zurück
- `GET /progress/{asin}` – gibt Fortschritt für ein Buch zurück
